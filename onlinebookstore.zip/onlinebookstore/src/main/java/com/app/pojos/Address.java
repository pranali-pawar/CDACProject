package com.app.pojos;
//package com.app.pojos;
//
//import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
//import javax.persistence.Id;
//import javax.persistence.JoinColumn;
//import javax.persistence.ManyToOne;
//import javax.persistence.Table;
//
//import lombok.AllArgsConstructor;
//import lombok.Getter;
//import lombok.NoArgsConstructor;
//import lombok.Setter;
//import lombok.ToString;
//@NoArgsConstructor
//@AllArgsConstructor
//@Getter
//@Setter
//@ToString

//@Entity
//@Table(name= "address")
//public class address {
//
//	@Id
//	@GeneratedValue(strategy=GenerationType.AUTO)
//@Column
//private int Addressid;
//@Column (length = 1000)
//private String address;
//@Column(length = 30)
//private String city;
//@Column(length = 30)
//private String state;
//@Column(length = 30)
//private String pincode;
//@Column(length = 10)
//private String mobilenumber;
//@ManyToOne
//@JoinColumn(name= "userid")
//private int userid;
//
//
//}
