package com.app.pojos;

public class BaseEntity {

}
