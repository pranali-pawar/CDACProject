function Contact (){
    return (
        <div>
        <h2>Contact us</h2>
       <div className="jumbotron text-center bg-dark text-white">
              <h3> Online Book Store</h3>
              <p> “There is no friend as loyal as a book.” </p>
              <p> Best Book store in town </p>
            
            </div>
    
            <div className="container">
    
                  <div className="row">
    
                    <div className="col-sm-4">
                    <h5>Customer Care Number</h5>
                     <p>1800 **** ****  </p>
                    </div>
    
                    <div className="col-sm-4">
                    <h5>Sell To us </h5>
                        <p>1800 **** ****</p>  
                    </div>
                   
                    <div className="col-sm-4">
                       <h5>For Account Recovery</h5>
                        <p>1800 **** **** </p>  
                    </div>
                  </div>
              </div>
    </div>
    );
}

export default Contact;