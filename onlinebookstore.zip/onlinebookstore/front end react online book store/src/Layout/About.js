function About (){
    return (
        

    <div>
    <h2>About us</h2>
   <div className="jumbotron text-center bg-dark text-white">
          <h3> Online Book Store</h3>
          <p> “There is no friend as loyal as a book.” </p>
          <p> Best Book store in town </p>
        
        </div>

        <div className="container">

              <div className="row">

                <div className="col-sm-4">
                    <h5>Top Rank Book Sore</h5>
                    <p>We are one of the highest rank book seller in town.</p>
                </div>

                <div className="col-sm-4">
                   <h5>Best Online Book Store</h5>
                    <p>We are one of the best online book seller.</p>  
                </div>
               
                <div className="col-sm-4">
                    <h5>Top low price book seller</h5>
                    <p>Selling low price books.</p>  
                </div>
              </div>
          </div>
</div>
    );
}

export default About;