function Help (){
    return (
        <div>
        <h2>Help</h2>
       <div className="jumbotron text-center bg-dark text-white">
              <h3> Online Book Store</h3>
              <p> “There is no friend as loyal as a book.” </p>
              <p> Best Book store in town </p>
            
            </div>
    
            <div className="container">
    
            <div className="row">
    
            <div className="col-sm-4">
            <h5>Customer Care Number</h5>
            <p>1800 **** ****  </p>
            </div>

           <div className="col-sm-4">
           <h5>Email us</h5>
           <p>help@onlinebookstore.com</p>  
           </div>
   
           <div className="col-sm-4">
           <h5>For Account Recovery</h5>
           <p>1800 **** **** </p>  
      </div>
  </div>
              </div>
    </div>
        
    );
}

export default Help;